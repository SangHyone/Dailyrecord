mkdir -p ~/src && cd ~/src
wget https://github.com/mozilla/geckodriver/releases/download/v0.21.0/geckodriver-v0.21.0-linux64.tar.gz
tar -zxvf geckodriver-v0.21.0-linux64.tar.gz
sudo mv geckodriver /usr/local/bin/
