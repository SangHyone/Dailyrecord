// 동기 방식
function buy_normal(item, price, quantity) {
    console.log(item + " 상품을 " + quantity + "개 골라서 점원에게 주었습니다.");
    console.log("계산이 필요합니다.");
    var total = price*quantity;
    return total;
}
// 시간이 조금 오래걸린다라고 가정하자
function buy_asis(item, price, quantity) {
    console.log(item + " 상품을 " + quantity + "개 골라서 점원에게 주었습니다.");
    setTimeout(function() {
        console.log("계산이 필요합니다.");
        var total = price*quantity;
        return total;
    }, 1000);
}

function pay(tot) {
    console.log(tot + "원을 지불하였습니다.");
}

// 동기식
//var tot = buy_normal("고구마", 1000, 5);
//pay(tot);

// 비동기식
// var tot = buy_asis("고구마", 1000, 5); // 계산이 완료되기 전에 리턴값을 사용해 버렸다.
// pay(tot);

// 함수의 마지막 인수로 완료 되었을떄 자동으로 실행시켜줄 함수를 전달 하도록 만든다.
function buy_tobe(item, price, quantity, callback) {
    console.log(item + " 상품을 " + quantity + "개 골라서 점원에게 주었습니다.");
    setTimeout(function() {
        console.log("계산이 필요합니다.");
        var total = price*quantity; // 계산
        callback(total); // 마지막에 인수로 전달된 콜백함수를 호출
    }, 1000);
}

buy_tobe('고구마', 1000, 5, pay);
