// 이전의 함수 작성 방법
function add(x, y){
	return x + y;
}
var x = 123;
var y = 456;
console. log(x + " + " + y + " = " + add(x, y))

// 화살표 함수가 추가 되었다.
const add2 = (x, y)=> x+y;
console. log(`${x} + ${y} = ${add2(x, y)}`)

const pow = (x, y) => x**y;
console. log(`2의 10승 = ${pow(2, 10)}`)