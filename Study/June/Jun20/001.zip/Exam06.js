// 예전방식
var f1 = {
	name : "한사람",
	ar : ["두사람","세사람","네사람","오사람"],
	logFriends : function(){
		var that = this;
		this.ar.forEach(function(item){
			console.log(that.name + " : " + item);
		});
	}
}
console.log(f1.logFriends());
// 현재 방식
let f2 = {
	name : "한사람",
	ar : ["두사람","세사람","네사람","오사람"],
	logFriends(){
		this.ar.forEach(item => {
			console.log(this.name + " : " + item);
		})
	}
}
console.log(f2.logFriends());
