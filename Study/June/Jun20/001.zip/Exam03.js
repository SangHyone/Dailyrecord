let a = 1;
let b = 2;
let result = a + b;
console.log(a  + ' 더하기 ' + b + '는 \'' + result + '\'입니다.');

// 백틱( ` )으로 감쌉니다(Tab 위에 있습니다). 
console.log(`${a } 더하기 ${b }는 '${result}'입니다.`);

