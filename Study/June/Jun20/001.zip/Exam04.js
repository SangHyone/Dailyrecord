// 이전의 객체에 속성을 추가하는 방법
var sayNode = function(){
	console.log('노드입니다.');
}
var es = 'JS';
var oldObj  ={ // 예전에는 반드시 JSON형식으로 속성을 지정해야 했다.
	sayJS : function(){
		console.log("자바스크립트");
	} ,
	sayNode :sayNode,
}
// 동적으로 속성 추가
oldObj[es + 6] = '판타스틱!!!'; // 속성명이 연산이 이루어져 JS6이 된다.
console.log(oldObj.JS6);
oldObj.sayNode();
oldObj.sayJS();

// ES6부터는 아래와 같이 속성추가가 가능하다.
const newObj = {
	sayJS(){
		console.log('새로운 문법으로 객체에 메서드 추가');
	},
	sayNode,
	[es + 6] : "정말 놀랍군"
}

console.log(newObj.JS6);
newObj.sayJS();
newObj.sayNode();


var name = "한사람";
var age = 33;

var obj1 = {
	"name":name, "age": age
};
console.log(obj1.name + "(" + obj1.age + '세)');

let obj2 = {name, age};
console.log(`${obj2.name}(${obj2.age}세)`);
