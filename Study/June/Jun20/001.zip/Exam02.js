if(true){
	var x = 100; // 전역변수
}
console.log('x = ' + x);

if(true){
	let x = 200; // 지역변수
}
console.log('x = ' + x);

if(true){
	const x = 300; // 지역변수 : 상수다
	// x = 400; // 변경 불가
}
console.log('x = ' + x);
