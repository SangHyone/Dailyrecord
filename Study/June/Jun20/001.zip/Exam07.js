// 변수 교환
let a = 10;
let b = 20;
console.log(`a = ${a}, b = ${b}`);
let t = a;
a = b;
b = t;
console.log(`a = ${a}, b = ${b}`);

a = a ^ b; // ^ bit XOR연산자
b = a ^ b;
a = a ^ b;
console.log(`a = ${a}, b = ${b}`);

// 최신 방법
[a, b] = [b, a];
console.log(`a = ${a}, b = ${b}`);

[ a,  ] = [b, a];
console.log(`a = ${a}, b = ${' ' }`);
