package kr.human.daehyung.service;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.daehyung.dao.InquiryBoardDAO;
import kr.human.daehyung.dao.InquiryBoardDAOImpl;
import kr.human.daehyung.dao.InquiryCommentBoardDAO;
import kr.human.daehyung.dao.InquiryCommentBoardDAOImpl;
import kr.human.mybatis.MybatisApp;
import kr.human.tw.vo.InquiryBoardVO;
import kr.human.tw.vo.InquiryCommentBoardVO;
import kr.human.tw.vo.PagingVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InquiryBoardServiceImpl implements InquiryBoardService {

	// 싱글톤 클래스로 만들자!!!
	private static InquiryBoardService instance = new InquiryBoardServiceImpl();

	private InquiryBoardServiceImpl() {
		;
	}

	public static InquiryBoardService getinstance() {
		return instance;
	}

	@Override
	public PagingVO<InquiryBoardVO> selectList(int currentPage, int pageSize, int blockSize) {
		log.info("InquiryBoardServiceImpl selectList 호출 : " + currentPage + ", " + pageSize + ", " + blockSize);
		PagingVO<InquiryBoardVO> pagingVO = null;
		SqlSession sqlSession = null;

		InquiryBoardDAO inquiryBoardDAO = null;

		/////////
		// 댓글부분 추가
		InquiryCommentBoardDAO inquiryCommentBoardDAO = null;
		/////////
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false); // 마지막에 commit하기 위해 false 로 설정
			inquiryBoardDAO = InquiryBoardDAOImpl.getInstance();
			inquiryCommentBoardDAO = InquiryCommentBoardDAOImpl.getInstance();
			// -----------------------------------------------

			// 1. 전체 개수를 구한다.
			int totalCount = inquiryBoardDAO.selectCount(sqlSession);

			// 2.페이지를 계산한다.
			pagingVO = new PagingVO<InquiryBoardVO>(totalCount, currentPage, pageSize, blockSize);
			// 3. 글목록을 가져온다.
			HashMap<String, Integer> map = new HashMap<>();
			map.put("startNo", pagingVO.getStartNo());
			map.put("endNo", pagingVO.getEndNo());

			// 4. 댓글 갯수를 얻기//
			List<InquiryBoardVO> list = inquiryBoardDAO.selectList(sqlSession, map);
			if (list != null) {
				for (InquiryBoardVO vo : list) {
					vo.setCommentCount(inquiryCommentBoardDAO.selectCount(sqlSession, vo.getInquiry_idx()));
				}
			}

			// -----------------------------------------------

			// 5. 글의 목록을 pagingVO에 넣어준다.
			pagingVO.setList(list);
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}

		log.info("InquiryBoardServiceImpl selectList 리턴 : " + pagingVO);
		return pagingVO;
	}

	@Override
	public InquiryBoardVO selectByIdx(int inquiry_idx, boolean isClick) {
		log.info("InquiryBoardServiceImpl selectByIdx 호출 : " + inquiry_idx + ", " + isClick);
		InquiryBoardVO inquiryBoardVO = null;

		SqlSession sqlSession = null;
		InquiryBoardDAO inquiryBoardDAO = null;
		InquiryCommentBoardDAO inquiryCommentBoardDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			inquiryBoardDAO = InquiryBoardDAOImpl.getInstance();
			inquiryCommentBoardDAO = InquiryCommentBoardDAOImpl.getInstance();
			// -----------------------------------------------
			// 1. 해당 글번호의 글을 가져온다.
			inquiryBoardVO = inquiryBoardDAO.selectByIdx(sqlSession, inquiry_idx);

			// 2. 해당글이 존재하면 정보를 가져온다.
			if (inquiryBoardVO != null && isClick) {
				inquiryBoardVO.setClickCount(inquiryBoardVO.getClickCount() + 1); // 나의 조회수 증가
				inquiryBoardDAO.increment(sqlSession, inquiry_idx); // DB의 조회수 증가.
			}
			// -----------------------------------------------
			// 댓글로 인한 추가
			if (inquiryBoardVO != null) {
				// 글에대한 댓글의 목록을 넣어준다.
				inquiryBoardVO.setCommentList(
						inquiryCommentBoardDAO.selectList(sqlSession, inquiryBoardVO.getInquiry_idx()));
				inquiryBoardVO.setCommentCount(
						inquiryCommentBoardDAO.selectCount(sqlSession, inquiryBoardVO.getInquiry_idx()));
			}
			
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		log.info("InquiryBoardServiceImpl selectByIdx 리턴 : " + inquiryBoardVO);
		return inquiryBoardVO;
	}

	@Override
	public void insert(InquiryBoardVO inquiryBoardVO) {
		log.info("InquiryBoardServiceImpl insert 호출 : " + inquiryBoardVO);

		SqlSession sqlSession = null;
		InquiryBoardDAO inquiryBoardDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			inquiryBoardDAO = InquiryBoardDAOImpl.getInstance();
			// -----------------------------------------------
			// 1.원본글이 존재하면
			if (inquiryBoardVO != null) {
				// 2. 원본글을 저장한다
				inquiryBoardDAO.insert(sqlSession, inquiryBoardVO);
			}

			// -----------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
	}

	@Override
	public void update(InquiryBoardVO inquiryBoardVO) {
		log.info("InquiryBoardServiceImpl update 호출 : " + inquiryBoardVO);
		// ------------------------------------------------------------
		SqlSession sqlSession = null;
		InquiryBoardDAO inquiryBoardDAO = null;

		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			inquiryBoardDAO = InquiryBoardDAOImpl.getInstance();

			// --------------------------------------------------------------------
			// 1. 원본글이 존재하면
			if (inquiryBoardVO != null) {
				// 2. db에서 해당 글번호의 글을 읽어온다.
				InquiryBoardVO dbVO = inquiryBoardDAO.selectByIdx(sqlSession, inquiryBoardVO.getInquiry_idx());
				// 3. db에 글이 있으면서 유저idx가 일치할때만 수정 진행
				if (dbVO != null && dbVO.getInquiry_idx() == inquiryBoardVO.getInquiry_idx()) {
					inquiryBoardDAO.update(sqlSession, inquiryBoardVO);
				}
			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

	@Override
	public void delete(InquiryBoardVO inquiryBoardVO) {
		log.info("InquiryBoardServiceImpl delete 호출 : " + inquiryBoardVO);
		// ------------------------------------------------------------
		SqlSession sqlSession = null;
		InquiryBoardDAO inquiryBoardDAO = null;
		InquiryCommentBoardDAO inquiryCommentBoardDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			inquiryBoardDAO = InquiryBoardDAOImpl.getInstance();
			inquiryCommentBoardDAO = InquiryCommentBoardDAOImpl.getInstance();

			// --------------------------------------------------------------------
			// 1. 원본글이 존재하면
			if (inquiryBoardVO != null) {
				// 2. db에서 해당 글번호의 글을 읽어온다.
				InquiryBoardVO dbVO = inquiryBoardDAO.selectByIdx(sqlSession, inquiryBoardVO.getInquiry_idx());
				// 3. db에 글이 있으면서 유저idx 일치할때만 수정을 수행한다.
				if (dbVO != null && dbVO.getUser_idx() == inquiryBoardVO.getUser_idx()) {

					// 삭제하기 전에 댓글들을 모두 삭제해야만 원본 글을 삭제 할 수 있다.
					inquiryCommentBoardDAO.deleteByRef(sqlSession, inquiryBoardVO.getInquiry_idx());
					// 원본글 삭제
					inquiryBoardDAO.delete(sqlSession, inquiryBoardVO.getInquiry_idx());
				}
			}

			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

	// 댓글 저장
	@Override
	public void commentInsert(InquiryCommentBoardVO inquiryCommentBoardVO) {
		log.info("InquiryBoardServiceImpl commentInsert 호출 : " + inquiryCommentBoardVO);
		SqlSession sqlSession = null;
		InquiryCommentBoardDAO inquiryCommentBoardDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			inquiryCommentBoardDAO = InquiryCommentBoardDAOImpl.getInstance();
			// --------------------------------------------------------------------
			if (inquiryCommentBoardVO != null) {
				inquiryCommentBoardDAO.insert(sqlSession, inquiryCommentBoardVO);

			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

	// 댓글 수정
	@Override
	public void commentUpdate(InquiryCommentBoardVO inquiryCommentBoardVO) {
		log.info("InquiryBoardServiceImpl commentUpdate 호출 : " + inquiryCommentBoardVO);
		// ------------------------------------------------------------
		SqlSession sqlSession = null;
		InquiryCommentBoardDAO inquiryCommentBoardDAO = null;

		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			inquiryCommentBoardDAO = InquiryCommentBoardDAOImpl.getInstance();

			// --------------------------------------------------------------------
			if (inquiryCommentBoardDAO != null) {
				// 아이디가 같을떄만 수정
				InquiryCommentBoardVO dbVO = inquiryCommentBoardDAO.selectByIdx(sqlSession,
						inquiryCommentBoardVO.getInquiry_comment_idx());
				if (dbVO != null && dbVO.getId().equals(inquiryCommentBoardVO.getId())) {
					inquiryCommentBoardDAO.update(sqlSession, inquiryCommentBoardVO);
				}
			}

			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

	// 댓글 삭제
	@Override
	public void commentDelete(InquiryCommentBoardVO inquiryCommentBoardVO) {
		log.info("InquiryBoardServiceImpl commentDelete 호출 : " + inquiryCommentBoardVO);
		// ------------------------------------------------------------
		SqlSession sqlSession = null;
		InquiryCommentBoardDAO inquiryCommentBoardDAO = null;

		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			inquiryCommentBoardDAO = InquiryCommentBoardDAOImpl.getInstance();

			// --------------------------------------------------------------------
			if (inquiryCommentBoardDAO != null) {
				// 아이디가 같을떄만 수정
				InquiryCommentBoardVO dbVO = inquiryCommentBoardDAO.selectByIdx(sqlSession,
						inquiryCommentBoardVO.getInquiry_comment_idx());
				log.info(dbVO.toString());
				if (dbVO != null && dbVO.getId().equals(inquiryCommentBoardVO.getId())) {
					inquiryCommentBoardDAO.delete(sqlSession, inquiryCommentBoardVO.getInquiry_comment_idx());
				}
			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

}
