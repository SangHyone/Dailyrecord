package kr.human.user.service;


import javax.servlet.http.HttpSession;

import kr.human.tw.vo.PagingVO;
import kr.human.tw.vo.UserVO;

public interface UserService {
	// 저장(회원가입)
	void insert(UserVO userVO, String urlAddress);
	// 수정(정보수정)
	void update(UserVO userVO, String newPassword, HttpSession httpSession);
	// 삭제(회원탈퇴)
	void delete(UserVO userVO, HttpSession httpSession);
	// 목록보기(관리자)
	PagingVO<UserVO> selectList(int currentPage, int pageSize, int blockSize);
	// 아이디 찾기
	UserVO searchUserid(String name, String phone); 
	// 비번 찾기
	UserVO searchPassword(String id, String phone); 
	// 로그인
	boolean login(String id, String password, HttpSession httpSession);
	// 로그아웃
	void logout();
	// 인증하기
	boolean emailConfirm(String id);
	// 아이디 중복확인
	int idCheck(String id);
	// 관리자 삭제
	void supervisorDelete(UserVO userVO);
	// 관리자 수정
	void supervisorUpdate(UserVO userVO, String name);
}
