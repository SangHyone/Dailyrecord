package kr.human.saerom.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.FreeCommentVO;

public class FreeCommentDAOImpl implements FreeCommentDAO{
	//싱글톤
	private static FreeCommentDAO instance = new FreeCommentDAOImpl();
	private FreeCommentDAOImpl() {}
	public static FreeCommentDAO getInstance() {return instance;}
	
	
	@Override
	public int selectCount(SqlSession sqlSession, int ref) throws SQLException {
		return sqlSession.selectOne("freeComment.selectCount",ref);
	}
	@Override
	public List<FreeCommentVO> selectList(SqlSession sqlSession, int ref) throws SQLException {
		return sqlSession.selectList("freeComment.selectList",ref);
	}
	@Override
	public FreeCommentVO selectByIdx(SqlSession sqlSession,int fc_idx) throws SQLException {
		return sqlSession.selectOne("freeComment.selectByIdx",fc_idx);
	}
	@Override
	public void insert(SqlSession sqlSession, FreeCommentVO freeCommentVO) throws SQLException {
		sqlSession.insert("freeComment.insert",freeCommentVO);
		
	}
	@Override
	public void update(SqlSession sqlSession,  FreeCommentVO freeCommentVO) throws SQLException {
		sqlSession.update("freeComment.update", freeCommentVO);
		
	}
	@Override
	public void delete(SqlSession sqlSession, int fc_idx) throws SQLException {
		sqlSession.delete("freeComment.delete",fc_idx);
	}
	
	


}
