package kr.human.tw.vo;

import lombok.Data;

/*
DROP SEQUENCE upfile_idx_seq;
CREATE SEQUENCE upfile_idx_seq;
DROP TABLE upfile;
CREATE TABLE upfile(
	file_idx NUMBER PRIMARY KEY,
	board_idx NUMBER NOT NULL, -- 원본글번호
	user_idx NUMBER NOT NULL,
	ofileName varchar2(100) NOT NULL, -- 원본 파일명
	sfileName varchar2(100) NOT NULL  -- 저장 파일명
);

*/
 
@Data
public class UpFileVO {
	private int file_idx;
	private int board_idx;
	private int user_idx;
	private String id;
	private String ofileName;
	private String sfileName;
}
