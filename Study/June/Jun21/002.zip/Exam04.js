console.log(__filename); // 파일 전체 경로
console.log(__dirname);  // 파일 폴더 경로