const url = require('url');
const querystring = require('querystring'); // 요청정보를 파싱하는 모듈
const parsedUrl = url.parse('http://www.gilbut.co.kr/?page=3&limit=10&category=nodejs&category=javascript');
const query = querystring.parse(parsedUrl.query);
console.log('querystring.parse():', query);
console.log('querystring.stringify():', querystring.stringify(query));
let param = {
	"p":1,
	"s":10,
	"b":10
};
console.log('querystring.stringify():', querystring.stringify(param));
console.log("list.jsp?" + querystring.stringify(param));