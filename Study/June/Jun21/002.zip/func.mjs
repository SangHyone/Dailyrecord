import { odd, even } from './var';
function checkOddOrEven(num) {
 	return num % 2 ? odd : even;
}
export default checkOddOrEven;