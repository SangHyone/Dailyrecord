const fs = require('fs'); // 파일 모듈을 사용하겠다.
// 파일을 읽어라
fs.readFile(__dirname + '/readme.txt', (err, data) => {
	if (err) { // 에러가 있으면 
		throw err; // 에러를 발생시켜라
	}
	console.log(data); // 읽은 내용을 출력해라. Buffer객체로 읽는다.
	console.log(data.toString()); // 문자열로 변경
});