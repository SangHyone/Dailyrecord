const {odd, even} = require('./var'); // 모듈을 읽어 들이겠다.
// 홀짝을 판단하는 함수
function checkOddOrEven(num){
	return num%2 ? odd : even;
}
// checkOddOrEven함수를 모듈로 쓰겠다.
module.exports = checkOddOrEven
