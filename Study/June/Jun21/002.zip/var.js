const odd='홀수';
const even='짝수';

module.exports = {
	odd,
	even
} 
