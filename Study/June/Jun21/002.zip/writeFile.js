const fs = require('fs');
fs.writeFile(__dirname + '/writeme.txt', '글이 입력됩니다', (err) => {
	if (err) {
		throw err;
	}
	fs.readFile(__dirname + '/writeme.txt', (err, data) => {
		if (err) {
			throw err;
		}
		console.log(data.toString());
	});
});