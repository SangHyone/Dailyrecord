// 같은 폴더에 있는 var.js파일에서 odd와 even을 가져다 사용하겠다
const {odd, even } = require('./var'); 
// 같은 폴더에 있는 func.js파일에서 checkOddOrEven을 가져다 사용하겠다
const checkNum = require('./func');

function checkStringOddOrEven(str) {
	return str.length % 2 ?  odd : even;
}
console.log(checkNum(10)); // 짝수
console.log(checkStringOddOrEven('hello')); // 길이가 홀수