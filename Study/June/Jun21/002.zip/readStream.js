const fs = require('fs');
// 파일의 크기가 엄청나게 클경우 메모리의 낭비를 줄일 수 있다.
// 버퍼의 크기를 16으로 지정하여 스트림으로 읽는다.
const readStream = fs.createReadStream(__dirname + '/readme3.txt', {
	highWaterMark: 16
});

const data = []; // 읽어서 쌓아놓을 배열 선언 

readStream.on('data', (chunk) => { // 읽은 내용이 chunk로 넘어온다.
	data.push(chunk); // 배열에 추가
	console.log('data :', chunk, chunk.length); // 출력
});

readStream.on('end', () => { // 마지막까지 읽으면
	console.log('end :', Buffer.concat(data).toString()); // 배열의 내용을 합쳐서 출력
});

readStream.on('error', (err) => { // 에러가 발생하면
	console.log('error :', err);
});