// 모듈 임포트하기
const http = require('http');
const fs = require('fs');
const url = require('url');
const qs = require('querystring');

// 쿠키 해석하기 함수
const parseCookies = (cookie = '') =>
	cookie
	.split(';')
	.map(v => v.split('='))
	.map(([k, ...vs]) => [k, vs.join('=')])
	.reduce((acc, [k, v]) => {
		acc[k.trim()] = decodeURIComponent(v);
		return acc;
	}, {});

// 서버 작성	
http.createServer((req, res) => {
		// 쿠키 해석
		const cookies = parseCookies(req.headers.cookie);
		// 접속주소가 /login으로 시작하면
		if (req.url.startsWith('/login')) {
			const {
				query
			} = url.parse(req.url); // URL해석
			const {
				name
			} = qs.parse(query); // 쿼리스트링 해석
			const expires = new Date(); // 날짜
			expires.setMinutes(expires.getMinutes() + 1); // 1분후
			// 헤더 지정
			res.writeHead(302, { // HTTP 상태코드 302는 다른곳으로 이동시킨다.
				Location: '/', // 루트로 이동
				// 유효기간을 지정하여 쿠키에 저장해서 /로 이동
				'Set-Cookie': `name=${encodeURIComponent(name)};Expires=${expires.toGMTString()}; HttpOnly; Path=/`, 
			});
			res.end();// 응답
		} else if (cookies.name) { // 쿠키에 이름이 있으면
			res.writeHead(200, { // 성공 응답
				'Content-Type': 'text/html; charset=utf-8'
			});
			res.end(`${cookies.name}님 안녕하세요`);
		} else { // login으로 시작하지도 않고 쿠키에 name도 없다면 server5.html파일을 읽어서 보여라
			fs.readFile(__dirname + '/server5.html', (err, data) => {
				if (err) {
					throw err;
				}
				res.end(data);
			});
		}
	})
	.listen(8083, () => { // 접속 대기
		console.log('http://127.0.0.1:8083 번 포트에서 서버 대기 중입니다!');
	});