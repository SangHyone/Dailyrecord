const http = require('http'); // http모듈을 사용 하겠다. 

const hostname = '127.0.0.1'; // 호스트 이름
const port = 3000; // 포트번호 지정

// 서버를 생성
const server = http.createServer((req, res) => {
	res.statusCode = 200; // 응답이 성공이다라고 지정
	res.setHeader('Content-Type', 'text/html'); // 문서형식 : html
	res.end('<h1>Hello World</h1>'); // 출력 : html형식으로 출력
});

// 접속 무한 대기
server.listen(port, hostname, () => {
	// 접속할 정보를 출력
	console.log(`Server running at http://${hostname}:${port}/`);
});