const http = require('http');
const parseCookies = (cookie = '') =>
	cookie
	.split(';')
	.map(v => v.split('='))
	.map(([k, ...vs]) => [k, vs.join('=')])
	.reduce((acc, [k, v]) => {
		acc[k.trim()] = decodeURIComponent(v);
		return acc;
	}, {});

http.createServer((req, res) => {
		console.log(req.headers.cookie);
		// 요청시 쿠키의 모든 정보를 파싱하는 함수를 호출
		const cookies = parseCookies(req.headers.cookie);
		console.log(req.url, cookies);
		res.writeHead(200, {
			'Set-Cookie': 'mycookie=' + encodeURIComponent('한글')
		});
		res.end('Hello Cookie');
	})
	.listen(8082, () => {
		console.log('http://127.0.0.1:8082 서버 대기 중입니다!');
	});