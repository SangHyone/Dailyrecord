// 모듈 임포트하기
const http = require('http');
const fs = require('fs');
const url = require('url');
const qs = require('querystring');

// 서버 작성	
http.createServer((req, res) => {
		if (req.url.startsWith('/a')) {
			const {
				query
			} = url.parse(req.url); // URL해석
			console.log("요청 : " + query);
			const {
				name
			} = qs.parse(query); // 쿼리스트링 해석
			console.log(`받은 내용 :  ${name}`);
			res.writeHead(200, { // 성공 응답
				'Content-Type': 'text/html; charset=utf-8'
			});
			res.end(`${name}님 안녕하세요`);

		}else if (req.url.startsWith('/b')) {
			const {
				query
			} = url.parse(req.url); // URL해석
			console.log("요청 : " + query);
			const {
				name, age
			} = qs.parse(query); // 쿼리스트링 해석
			console.log(`받은 내용 :  ${name}, ${age}`);
			res.writeHead(200, { // 성공 응답
				'Content-Type': 'text/html; charset=utf-8'
			});
			res.end(`${name}님 ${age}살이네 행님이라 불러!!!`);
		} else{
			res.writeHead(200, { // 성공 응답
				'Content-Type': 'text/html; charset=utf-8'
			});
			res.end(`http://127.0.0.1:8083/a?name=kimc 또는 http://127.0.0.1:8083/b?name=kimc&age=33 으로 접속해봐!!!`);
		}
	})
	.listen(8083, () => { // 접속 대기
		console.log('http://127.0.0.1:8083 번 포트에서 서버 대기 중입니다!');
		console.log('http://127.0.0.1:8083/a?name=이름 ');
		console.log('http://127.0.0.1:8083/b?name=이름&age=23');
	});