package kr.human.saerom.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.FreeBoardVO;

public class FreeBoardDAOImpl implements FreeBoardDAO{
	private static FreeBoardDAO instance= new FreeBoardDAOImpl();
	private FreeBoardDAOImpl() {}
	public static FreeBoardDAO getInstance() {return instance;}
	@Override
	public int selectCount(SqlSession sqlSession) throws SQLException {
		return sqlSession.selectOne("freeBoard.selectCount");
	}
	@Override
	public FreeBoardVO selectByIdx(SqlSession sqlSession, int free_idx) throws SQLException {
		return sqlSession.selectOne("freeBoard.selectByIdx",free_idx);
	}
	@Override
	public List<FreeBoardVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException {
		return sqlSession.selectList("freeBoard.selectList", map);
	}

	@Override
	public void insert(SqlSession sqlSession, FreeBoardVO freeVO) throws SQLException {
		sqlSession.insert("freeBoard.insert",freeVO);
		
	}
	@Override
	public void update(SqlSession sqlSession, FreeBoardVO freeVO) throws SQLException {
	sqlSession.update("freeBoard.update",freeVO);	
	}
	@Override
	public void delete(SqlSession sqlSession, int free_idx) throws SQLException {
		sqlSession.delete("freeBoard.delete",free_idx);
		
	}
	@Override
	public void increment(SqlSession sqlSession, int free_idx) throws SQLException {
	sqlSession.selectOne("freeBoard.increment",free_idx);
	}
	@Override
	public void likeCount(SqlSession sqlSession, int free_idx) throws SQLException {
	sqlSession.selectOne("freeBoard.likeCount",free_idx);
	}

	

}
