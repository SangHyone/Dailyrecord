package kr.human.twboard.dao;

import java.sql.SQLException;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.LikeCheckVO;

public class LikeCheckDAOImpl implements LikeCheckDAO{
	private static LikeCheckDAO instance = new LikeCheckDAOImpl();
	private LikeCheckDAOImpl() {}
	public static LikeCheckDAO getInstance() {
		return instance;
	}
	//--------------------------------------------------------------------------------------------------------------

	
	// 1. 해당 글번호 와 id를 통해 불러오기 
	@Override
	public int selectByidxAndid(SqlSession sqlSession, LikeCheckVO likeCheckVO) throws SQLException {
		return sqlSession.selectOne("likeCheck.selectByidxAndid", likeCheckVO);
	}
	
	// 2. 저장 
	@Override
	public void likeInsert(SqlSession sqlSession, LikeCheckVO likeCheckVO) throws SQLException {
		sqlSession.insert("likeCheck.likeInsert", likeCheckVO);
		
	}
	
	// 3. 삭제 
	@Override
	public void deleteByidxAndid(SqlSession sqlSession, LikeCheckVO likeCheckVO) throws SQLException {
		sqlSession.delete("likeCheck.deleteByidxAndid", likeCheckVO);
	}
	
}
