package kr.human.tw.vo;

import java.util.Date;

import lombok.Data;

@Data
public class FreeCommentVO {
	private int fc_idx;
	private int ref;
	private String nick;
	private String password;
	private String content;
	private Date regDate;
	
	private String mode;
}
/*

CREATE SEQUENCE fc_idx_seq;
CREATE TABLE freeComment(
	fc_idx NUMBER PRIMARY KEY,
	REF int NOT NULL,
	nick varchar2(50) NOT NULL,
	password varchar2(50) NOT NULL,
	content varchar2(500) NOT NULL,
	regDate DATE default SYSDATE,
	FOREIGN key(ref) REFERENCES freeboard(free_idx)
);
*/
 