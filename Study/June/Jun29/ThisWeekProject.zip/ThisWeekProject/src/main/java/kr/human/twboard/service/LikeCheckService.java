package kr.human.twboard.service;


public interface LikeCheckService {
	
	// 1. 글번호 와 id를 통해 현재 접속한 유저가 이 글을 추천 했는지에 대한 여부 판단하기
	int selectWhether(int board_idx, String id);
	
	// 2. 추천하기
	void likeInsert(int board_idx, String id);
	
	// 3. 추천 취소하기
	void likeCancel(int board_idx, String id);
	
	
}
