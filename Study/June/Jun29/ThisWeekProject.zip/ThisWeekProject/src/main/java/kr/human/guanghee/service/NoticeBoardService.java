package kr.human.guanghee.service;

import kr.human.tw.vo.NoticeBoardVO;
import kr.human.tw.vo.NoticeCommentVO;
import kr.human.tw.vo.PagingVO;

public interface NoticeBoardService {
	//목록보기
	PagingVO<NoticeBoardVO> selectList(int currentPage, int pageSize, int blockSize);
	//내용보기
	NoticeBoardVO selectByIdx(int notice_idx,boolean isClick);
	//저장하기
	void insert(NoticeBoardVO noticeBoardVO);
	//수정하기
	void update(NoticeBoardVO noticeBoardVO);
	//삭제하기
	void delete(NoticeBoardVO noticeBoardVo);
	
	//댓글 부분 추가
	// 댓글 저장
	void commentInsert(NoticeCommentVO noticeCommentVO);
	// 댓글 수정
	void commentUpdate(NoticeCommentVO noticeCommentVO);
	// 댓글 삭제
	void commentDelete(NoticeCommentVO noticeCommentVO);
}
