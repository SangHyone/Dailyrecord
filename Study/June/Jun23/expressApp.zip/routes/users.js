var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

router.get('/flash', function (req, res) {
  req.session.message = '세션 메시지';  // 세션에 변수 등록
  req.flash('message', 'flash 메시지'); // 1회용메서지 등록
  res.redirect('/users/flash/result'); // 이동
});
router.get('/flash/result', function (req, res) {
  // 출력  : 세션의 message와 1회용 메세지를 출력한다.
  res.send(`${req.session.message} ${req.flash('message')}`);
});


module.exports = router;