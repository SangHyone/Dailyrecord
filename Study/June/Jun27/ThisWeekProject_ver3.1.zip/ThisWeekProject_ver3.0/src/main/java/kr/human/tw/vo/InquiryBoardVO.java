package kr.human.tw.vo;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class InquiryBoardVO {
	private int inquiry_idx; // 글번호
	private String id; // 작성자 아이디
	private int user_idx;
	private String subject; // 제목
	private String content; // 내용
	private Date regDate; // 작성일
	private int clickCount; // 조회수
	private String answerCheck; // 답변상태확인
	private String openCheck; // 공개여부
	
	
	
	private String mode;// 저장/수정/삭제 구분하기 위한 필드
	// 댓글의 정보를 저장할 변수 추가
	private int commentCount;	// 목록보기 갯수
	private List<InquiryCommentBoardVO> commentList;	// 내용보기에서는 댓글 필요

	

}


