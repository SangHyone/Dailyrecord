package kr.human.twboard.service;

import kr.human.tw.vo.CommentBoardVO;
import kr.human.tw.vo.PagingVO;
import kr.human.tw.vo.TwBoardVO;

public interface TwBoardService {
	// 1. 목록보기
	PagingVO<TwBoardVO> selectList(int currentPage, int pageSize, int blockSize);
	// 2. 내용보기	
	TwBoardVO selectByIdx(int board_idx, boolean isClick);
	// 3. 저장하기
	void insert(TwBoardVO twBoardVO);
	// 4. 수정하기
	void update(TwBoardVO twBoardVO, String path, String[] delfile);
	// 5. 삭제하기
	void delete(TwBoardVO twBoardVO, String path);
	
	// 6. 추천 증가
	void incrementLike(int board_idx);
	
	// 7. 추천 감소
	void decrementLike(int board_idx);
	
	
	
	
	// 댓글 부분 추가 
	// 6. 댓글 저장
	void commentInsert(CommentBoardVO commentBoardVO);
	// 7. 댓글 수정
	void commentUpdate(CommentBoardVO commentBoardVO);
	// 8. 댓글 삭제
	void commentDelete(CommentBoardVO commentBoardVO);
		
	
}
