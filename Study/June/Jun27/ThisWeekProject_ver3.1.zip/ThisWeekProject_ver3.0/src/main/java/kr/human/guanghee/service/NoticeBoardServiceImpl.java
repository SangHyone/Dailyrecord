package kr.human.guanghee.service;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.guanghee.dao.NoticeBoardDAO;
import kr.human.guanghee.dao.NoticeBoardDAOImpl;
import kr.human.guanghee.dao.NoticeCommentDAO;
import kr.human.guanghee.dao.NoticeCommentDAOImpl;
import kr.human.mybatis.MybatisApp;
import kr.human.tw.vo.NoticeBoardVO;
import kr.human.tw.vo.NoticeCommentVO;
import kr.human.tw.vo.PagingVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class NoticeBoardServiceImpl implements NoticeBoardService {
	private static NoticeBoardService instance = new NoticeBoardServiceImpl();

	private NoticeBoardServiceImpl() {
	}

	public static NoticeBoardService getInstance() {
		return instance;
	}

	// --------------------------------------------------------------------------------
	@Override
	public PagingVO<NoticeBoardVO> selectList(int currentPage, int pageSize, int blockSize) {
		log.info("NoticeBoardServiceImpl selectList 호출 : " + currentPage + ", " + pageSize + ", " + blockSize);
		PagingVO<NoticeBoardVO> pagingVO = null;
		SqlSession sqlSession = null;
		NoticeBoardDAO noticeBoardDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeBoardDAO = NoticeBoardDAOImpl.getInstance();
			// ---------------------------------------------------------------------------
			// 전체 개수
			int totalCount = noticeBoardDAO.selectCount(sqlSession);
			//// 2. 페이지를 계산한다.
			pagingVO = new PagingVO<NoticeBoardVO>(totalCount, currentPage, pageSize, blockSize);
			// 3. 글목록을 가져온다.
			HashMap<String, Integer> map = new HashMap<>();
			map.put("startNo", pagingVO.getStartNo());
			map.put("endNo", pagingVO.getEndNo());
			// 4. 각각의 글에 대하여 첨부파일 정보와 댓글 갯수를 얻어서 넣자!!!
			List<NoticeBoardVO> list = noticeBoardDAO.selectList(sqlSession, map);
			/*
			if (list != null) {
				for (NoticeBoardVO vo : list) {
					vo.setNoticecommentCount(noticeCommentDAO.selectCount(sqlSession, vo.getNotice_idx())); // 댓글 개수 얻어서
																											// 넣기
				}

			}
			*/
			// 5. 글의 목록을 pageingVO에 넣어준다.
			pagingVO.setList(list);
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		log.info("NoticeBoardServiceImpl selectList 리턴 : " + pagingVO);

		return pagingVO;
	}

	@Override
	public NoticeBoardVO selectByIdx(int notice_idx, boolean isClick) {
		log.info("NoticeBoardServiceImpl selectByIdx 호출 : " + notice_idx + ", " + isClick);
		NoticeBoardVO noticeBoardVO = null;
		SqlSession sqlSession = null;
		NoticeBoardDAO noticeBoardDAO = null;
		NoticeCommentDAO noticeCommentDAO = null; // 댓글 추가
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeBoardDAO = NoticeBoardDAOImpl.getInstance();
			
			noticeCommentDAO = NoticeCommentDAOImpl.getinstance();
			// --------------------------------------------------------------------
			// 1. 글번호의 글을 가져온다.
			noticeBoardVO = noticeBoardDAO.selectByIdx(sqlSession, notice_idx);
			// 2. 해당글이 존재하면 첨부파일의 정보를 가져온다.
			if (noticeBoardVO != null && isClick) { // 글이 존재하면서 isClick 참이면 조회수 증가
				noticeBoardVO.setClickCount(noticeBoardVO.getClickCount() + 1); // 나의 조회수 증가
				noticeBoardDAO.clickCountUp(sqlSession, notice_idx); // DB의 조회수 증가
			}

			// 댓글로 인한 추가
			
			if (noticeBoardVO != null) {
				// 글에 대한 댓글의 목록을 넣어준다.
				noticeBoardVO
						.setNoticecommentList(noticeCommentDAO.selectList(sqlSession, noticeBoardVO.getNotice_idx()));
				noticeBoardVO
						.setNoticecommentCount(noticeCommentDAO.selectCount(sqlSession, noticeBoardVO.getNotice_idx()));

			}
			

			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
		log.info("NoticeBoardServiceImpl selectByIdx 리턴 : " + noticeBoardVO);
		return noticeBoardVO;
	}

	@Override
	public void insert(NoticeBoardVO noticeBoardVO) {
		log.info("NoticeBoardServiceImpl insert 호출 : " + noticeBoardVO);
		// ------------------------------------------------------------
		SqlSession sqlSession = null;
		NoticeBoardDAO noticeBoardDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeBoardDAO = NoticeBoardDAOImpl.getInstance();
			// --------------------------------------------------------------------
			// 1. 권한이 관리자이며 원본글이 존재하면
					if (noticeBoardVO != null) {
					// 2. 원본글을 저장한다.
					noticeBoardDAO.insert(sqlSession, noticeBoardVO);
				}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

	@Override
	public void update(NoticeBoardVO noticeBoardVO) {
		log.info("NoticeBoardServiceImpl update 호출 : " + noticeBoardVO);
		// ------------------------------------------------------------
		SqlSession sqlSession = null;
		NoticeBoardDAO noticeBoardDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeBoardDAO = NoticeBoardDAOImpl.getInstance();
			// --------------------------------------------------------------------
			if (noticeBoardVO != null) {
				// 2. DB에서 해당 글번호의 글을 읽어온다.
				NoticeBoardVO dbVO = noticeBoardDAO.selectByIdx(sqlSession, noticeBoardVO.getNotice_idx());
				// 3. DB에 글이 있으면서 유저id가 일치할때만 수정을 수행한다.
				if (dbVO != null && dbVO.getId().equals(noticeBoardVO.getId()) ) {
					// 원본글 수정
					noticeBoardDAO.update(sqlSession, noticeBoardVO);
				}
			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

	@Override
	public void delete(NoticeBoardVO noticeBoardVO) {
		log.info("NoticeBoardServiceImpl delete 호출 : " + noticeBoardVO);
		// ------------------------------------------------------------
		SqlSession sqlSession = null;
		NoticeBoardDAO noticeBoardDAO = null;
		NoticeCommentDAO noticeCommentDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeBoardDAO = NoticeBoardDAOImpl.getInstance();
			noticeCommentDAO = NoticeCommentDAOImpl.getinstance();
			// --------------------------------------------------------------------
			// 1. 원본글이 존재하면
			if (noticeBoardVO != null) {
				// 2. DB에서 해당 글번호의 글을 읽어온다.
				NoticeBoardVO dbVO = noticeBoardDAO.selectByIdx(sqlSession, noticeBoardVO.getNotice_idx());
				// 3. DB에 글이 있고 유저id가 일치할때만 수정 가능
				if (dbVO != null && dbVO.getId().equals(noticeBoardVO.getId()) ) {
					
					//삭제하기 전에 댓글들을 모두 삭제해야만 원본 글을 삭제 할 수 있다.
					noticeCommentDAO.deleteByRef(sqlSession, noticeBoardVO.getNotice_idx());
					
					// 원본글 삭제
					noticeBoardDAO.delete(sqlSession, noticeBoardVO.getNotice_idx());
				}
			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------
	}

	
	
	// 댓굴 저장/수정/삭제
	@Override
	public void commentInsert(NoticeCommentVO noticeCommentVO) {
		log.info("NoticeBoardServiceImpl commentInsert 호출 : " + noticeCommentVO);
		SqlSession sqlSession = null;
		NoticeCommentDAO noticeCommentDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeCommentDAO = NoticeCommentDAOImpl.getinstance();
			// ---------------------------------------------------------------
			if (noticeCommentVO != null) {
				noticeCommentDAO.insert(sqlSession, noticeCommentVO);
			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		// ----------------------------------------------------------------------------------

	}

	@Override
	public void commentUpdate(NoticeCommentVO noticeCommentVO) {
		log.info("NoticeBoardServiceInpl commentUpdate 호출 : " + noticeCommentVO);
		SqlSession sqlSession = null;
		NoticeCommentDAO noticeCommentDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeCommentDAO = NoticeCommentDAOImpl.getinstance();
			// --------------------------------------------------------------
			if (noticeCommentVO != null) {
				// 아이디가 같아야 수정가능
				NoticeCommentVO dbcbVO = noticeCommentDAO.selectByIdx(sqlSession, noticeCommentVO.getNc_idx());
				log.info("dbcbVO" + dbcbVO);
				if (dbcbVO != null && dbcbVO.getId().equals(noticeCommentVO.getId())) {
					noticeCommentDAO.update(sqlSession, noticeCommentVO);
				}
			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
	}
	// ----------------------------------------------------------------------------------

	@Override
	public void commentDelete(NoticeCommentVO noticeCommentVO) {
		log.info("NoticeBoardServiceInpl commentDelete 호출 : " + noticeCommentVO);
		SqlSession sqlSession = null;
		NoticeCommentDAO noticeCommentDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			noticeCommentDAO = NoticeCommentDAOImpl.getinstance();
			// --------------------------------------------------------------
			if (noticeCommentVO != null) {
				// 아이디가 같아야 수정가능
				NoticeCommentVO dbcbVO = noticeCommentDAO.selectByIdx(sqlSession, noticeCommentVO.getNc_idx());
				if (dbcbVO != null && dbcbVO.getId().endsWith(noticeCommentVO.getId())) {
					noticeCommentDAO.delete(sqlSession, noticeCommentVO.getNc_idx());
				}
			}
			// --------------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
	}

}
