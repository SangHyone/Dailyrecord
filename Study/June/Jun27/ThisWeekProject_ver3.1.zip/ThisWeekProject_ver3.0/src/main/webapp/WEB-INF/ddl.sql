-- 시퀀스 2개 테이블 2개를 만들자!!!!
DROP SEQUENCE twBoard_idx_seq;

DROP SEQUENCE user_idx_seq;
-- user시퀀스
CREATE SEQUENCE user_idx_seq;

-- 유저 테이블생성
CREATE TABLE user_info(
	user_idx NUMBER PRIMARY KEY,
	id varchar2(50) NOT NULL UNIQUE,
	password varchar2(50) NOT NULL,
	name varchar2(50) NOT NULL,
	birth DATE NOT NULL,
	gender char(1) NOT NULL check(gender IN ('M', 'F')),
	email varchar2(50) NOT NULL,
	phone varchar2(20) NOT NULL,
	postCode varchar2(10) NOT NULL,
	addr1 varchar2(200) NOT NULL,
	addr2 varchar2(200) NOT NULL,
	use NUMBER check(use IN (0,1)),
	lev NUMBER check(lev IN (0,1,2,3))
);

-- <동원 테이블>
-- board시퀀스
CREATE SEQUENCE twBoard_idx_seq;
-- upfile시퀀스
CREATE SEQUENCE upfile_idx_seq;
-- comment시퀀스
CREATE SEQUENCE comment_idx_seq;
-- likeCheck시퀀스
CREATE SEQUENCE like_idx_seq;


-- 게시판 테이블생성
CREATE TABLE twboard(
   board_idx NUMBER PRIMARY KEY,
   category varchar2(100) check(category IN ('free', 'travel', 'restaurant', 'sport')) NOT NULL,
   subject varchar2(100) NOT NULL,
   pay NUMBER,
   content varchar2(3000) NOT NULL,
   address varchar2(200) NOT NULL,
   clickCount NUMBER,
   likeCount NUMBER,
   commentCount NUMBER,
   regDate timestamp DEFAULT SYSDATE,
   user_idx NUMBER,
   id varchar2(50) NOT NULL
);

-- 이미지테이블 생성
CREATE TABLE upfile(
   file_idx NUMBER PRIMARY KEY,
   board_idx NUMBER NOT NULL, -- 원본글번호
   user_idx NUMBER NOT NULL,
   ofileName varchar2(100) NOT NULL, -- 원본 파일명
   sfileName varchar2(100) NOT NULL  -- 저장 파일명
);

-- 댓글테이블 생성
CREATE TABLE commentboard(
   comment_idx NUMBER PRIMARY KEY,
   board_idx NUMBER NOT NULL,
   user_idx NUMBER NOT NULL,
   id varchar2(50) NOT NULL,
   content varchar2(200) NOT NULL,
   regDate   timestamp DEFAULT sysdate,
   category varchar2(100) NOT NULL check(category IN ('free', 'travel', 'restaurant', 'sport'))
);


CREATE TABLE likeCheck(
   like_idx number PRIMARY KEY,
   board_idx number NOT NULL,
   id varchar2(50) NOT NULL
);




-- 광희 테이블--
CREATE SEQUENCE notice_idx_seq;

CREATE TABLE noticeBoard(
   notice_idx NUMBER PRIMARY KEY,
   id varchar2(50) NOT NULL,
   subject varchar2(200) NOT NULL,
   content varchar2(3000) NOT NULL,
   regDate timestamp DEFAULT SYSDATE,
   clickCount NUMBER,
   likeCount NUMBER
);

CREATE SEQUENCE nc_idx_seq;

CREATE TABLE noticeComment(
   nc_idx NUMBER PRIMARY KEY,
   notice_idx NUMBER NOT NULL,
   id varchar2(50) NOT NULL,
   content varchar2(200) NOT NULL,
   regDate timestamp DEFAULT sysdate,
   likeCount number
);
DROP TABLE noticeComment;
-- 새롬 테이블 --

CREATE SEQUENCE free_idx_seq;
CREATE TABLE freeboard(
	free_idx NUMBER PRIMARY KEY,
	nick varchar2(50) NOT NULL,
	password varchar2(50) NOT NULL,
	subject varchar2(200) NOT NULL,
	content varchar2(3000) NOT NULL,
	regDate DATE default sysdate,
	clickCount NUMBER,
	likeCount NUMBER
);


CREATE SEQUENCE fc_idx_seq;
CREATE TABLE freeComment(
	fc_idx NUMBER PRIMARY KEY,
	ref int NOT NULL,
	nick varchar2(50) NOT NULL,
	password varchar2(50) NOT NULL,
	content varchar2(500) NOT NULL,
	regDate DATE default SYSDATE
);

/* 대형 테이블 - */----------------------------------------------
-- 문의게시판 시퀀스 
CREATE SEQUENCE inquiry_idx_seq;
-- 문의게시판 답변댓글 시퀀스
CREATE SEQUENCE inquiry_comment_idx_seq;

--문의게시판 테이블
CREATE TABLE inquiry_board(
   inquiry_idx NUMBER PRIMARY KEY,
   id varchar2(50) NOT NULL UNIQUE,
   subject varchar2(200) NOT NULL,
   content varchar2(500) NOT NULL,
   regDate DATE DEFAULT SYSDATE,
   clickCount NUMBER,
   user_idx NUMBER,
   answerCheck char(1) check(answerCheck IN ('Y','N')) NOT NULL,
   openCheck char(1) check(openCheck IN ('Y','N')) NOT NULL,
   commentCount NUMBER
);

-- 문의 게시판 댓글테이블
CREATE TABLE inquiry_CommentBoard(
   inquiry_comment_idx NUMBER PRIMARY KEY,
   inquiry_idx NUMBER NOT NULL,
   id varchar2(50) NOT NULL,
   content varchar2(200) NOT NULL,
   user_idx NUMBER,
   regDate DATE DEFAULT SYSDATE
);


SELECT * FROM inquiry_board;
SELECT * FROM inquiry_CommentBoard;


-- 관리자모드 기본 아이디 삽입
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'root','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 3);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'admin','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 3);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'master','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 3);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'webmaster','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 3);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'sys','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 3);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'system','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 3);

-- FK 추가 부분.
ALTER TABLE twboard
ADD CONSTRAINT fk_user_idx foreign KEY(user_idx) references user_info (user_idx);

ALTER TABLE upfile
ADD CONSTRAINT fk_board_idx foreign KEY(board_idx) references twboard (board_idx);


DROP SEQUENCE upfile_idx_seq;

DROP TABLE upfile;



SELECT * FROM tab;
 SELECT * FROM TWBOARD ;
 SELECT count(*) FROM TWBOARD ;
SELECT * FROM USER_INFO;
DROP TABLE USER_INFO;
DROP TABLE TWBOARD;
DROP TABLE commentboard;
DROP TABLE upfile;
SELECT * FROM NOTICECOMMENT n ;

